package me.tokyomap.dto.maps;

import lombok.Data;

@Data
public class Geometry {
    private Location location;
}
