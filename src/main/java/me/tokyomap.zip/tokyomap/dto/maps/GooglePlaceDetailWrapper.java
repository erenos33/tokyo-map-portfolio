package me.tokyomap.dto.maps;

import lombok.Data;

@Data
public class GooglePlaceDetailWrapper {
    private GooglePlaceDetailResponseDto result;
}