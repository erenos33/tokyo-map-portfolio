package me.tokyomap.domain.user.role;

public enum UserRole {
    USER, ADMIN
}
